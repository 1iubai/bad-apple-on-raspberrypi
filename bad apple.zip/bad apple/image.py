# Copyright (c) 2014 Adafruit Industries
# Author: Tony DiCola
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
import time

import Adafruit_GPIO.SPI as SPI
import Adafruit_SSD1306

from PIL import Image


# Raspberry Pi pin configuration:
RST = 24
# Note the following are only used with SPI:
DC = 23
SPI_PORT = 0
SPI_DEVICE = 0

# Beaglebone Black pin configuration:
# RST = 'P9_12'
# Note the following are only used with SPI:
# DC = 'P9_15'
# SPI_PORT = 1
# SPI_DEVICE = 0

# 128x32 display with hardware I2C:
disp = Adafruit_SSD1306.SSD1306_128_32(rst=RST)

# 128x64 display with hardware I2C:
# disp = Adafruit_SSD1306.SSD1306_128_64(rst=RST)

# 128x32 display with hardware SPI:
# disp = Adafruit_SSD1306.SSD1306_128_32(rst=RST, dc=DC, spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE, max_speed_hz=8000000))

# 128x64 display with hardware SPI:
# disp = Adafruit_SSD1306.SSD1306_128_64(rst=RST, dc=DC, spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE, max_speed_hz=8000000))

# Initialize library.
disp.begin()
# Clear display.
disp.clear()
disp.display()
# Load image based on OLED display height.  Note that image is converted to 1 bit color.
# Alternatively load a different format image, resize it, and convert to 1 bit color.
#image = Image.open('happycat.png').resize((disp.width, disp.height), Image.ANTIALIAS).convert('1')

# Display image.
image = Image.open('bad (1).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (7).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (8).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (9).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (10).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (11).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (12).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (13).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (14).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (15).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (16).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (17).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (18).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (19).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (20).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (21).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (22).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (23).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (24).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (25).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (26).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (27).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (28).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (29).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (30).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (31).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (32).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (33).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (34).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (35).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (36).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (37).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (38).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (39).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (40).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (41).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (42).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (43).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (44).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (45).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (46).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (47).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (48).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (49).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (50).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (51).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (52).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (53).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (54).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (55).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (56).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (57).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (58).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (59).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (60).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (61).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (62).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (63).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (64).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (65).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (66).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (67).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (68).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (69).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (70).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (71).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (72).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (73).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (74).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (75).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (76).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (77).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (78).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (79).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (80).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (81).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (82).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (83).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (84).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (85).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (86).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (87).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (88).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (89).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (90).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (91).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (92).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (93).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (94).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (95).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (96).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (97).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (98).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (99).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (100).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (101).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (102).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (103).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (104).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (105).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (106).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (107).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (108).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (109).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (110).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (111).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (112).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (113).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (114).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (115).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (116).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (117).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (118).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (119).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (120).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (121).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (122).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (123).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (124).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (125).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (126).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (127).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (128).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (129).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (130).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (131).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (132).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (133).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (134).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (135).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (136).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (137).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (138).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (139).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (140).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (141).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (142).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (143).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (144).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (145).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (146).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (147).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (148).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (149).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (150).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (151).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (152).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (153).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (154).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (155).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (156).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (157).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (158).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (159).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (160).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (161).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (162).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (163).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (164).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (165).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (166).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (167).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (168).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (169).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (170).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (171).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (172).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (173).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (174).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (175).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (176).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (177).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (178).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (179).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (180).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (181).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (182).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (183).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (184).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (185).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (186).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (187).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (188).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (189).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (190).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (191).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (192).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (193).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (194).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (195).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (196).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (197).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (198).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (199).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (200).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (201).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (202).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (203).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (204).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (205).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (206).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (207).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (208).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (209).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (210).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (211).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (212).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (213).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (214).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (215).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (216).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (217).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (218).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (219).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (220).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (221).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (222).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (223).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (224).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (225).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (226).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (227).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (228).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (229).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (230).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (231).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (232).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (233).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (234).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (235).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (236).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (237).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (238).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (239).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (240).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (241).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (242).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (243).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (244).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (245).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (246).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (247).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (248).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (249).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (250).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (251).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (252).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (253).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (254).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (255).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (256).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (257).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (258).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (259).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (260).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (261).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (262).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (263).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (264).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (265).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (266).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (267).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (268).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (269).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (270).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (271).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (272).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (273).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (274).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (275).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (276).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (277).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (278).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (279).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (280).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (281).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (282).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (283).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (284).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (285).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (286).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (287).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (288).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (289).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (290).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (291).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (292).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (293).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (294).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (295).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (296).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (297).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (298).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (299).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (300).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (301).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (302).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (303).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (304).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (305).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (306).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (307).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (308).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (309).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (310).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (311).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (312).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (313).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (314).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (315).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (316).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (317).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (318).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (319).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (320).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (321).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (322).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (323).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (324).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (325).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (326).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (327).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (328).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (329).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (330).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (331).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (332).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (333).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (334).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (335).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (336).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (337).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (338).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (339).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (340).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (341).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (342).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (343).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (344).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (345).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (346).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (347).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (348).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (349).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (350).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (351).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (352).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (353).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (354).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (355).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (356).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (357).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (358).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (359).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (360).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (361).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (362).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (363).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (364).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (365).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (366).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (367).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (368).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (369).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (370).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (371).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (372).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (373).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (374).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (375).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (376).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (377).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (378).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (379).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (380).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (381).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (382).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (383).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (384).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (385).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (386).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (387).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (388).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (389).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (390).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (391).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (392).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (393).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (394).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (395).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (396).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (397).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (398).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (399).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (400).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (401).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (402).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (403).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (404).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (405).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (406).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (407).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (408).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (409).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (410).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (411).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (412).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (413).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (414).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (415).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (416).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (417).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (418).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (419).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (420).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (421).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (422).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (423).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (424).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (425).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (426).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (427).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (428).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (429).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (430).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (431).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (432).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (433).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (434).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (435).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (436).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (437).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (438).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (439).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (440).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (441).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (442).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (443).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (444).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (445).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (446).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (447).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (448).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (449).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (450).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (451).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (452).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (453).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (454).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (455).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (456).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (457).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (458).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (459).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (460).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (461).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (462).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (463).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (464).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (465).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (466).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (467).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (468).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (469).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (470).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (471).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (472).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (473).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (474).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (475).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (476).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (477).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (478).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (479).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (480).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (481).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (482).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (483).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (484).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (485).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (486).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (487).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (488).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (489).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (490).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (491).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (492).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (493).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (494).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (495).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (496).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (497).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (498).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (499).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (500).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (501).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (502).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (503).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (504).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (505).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (506).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (507).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (508).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (509).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (510).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (511).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (512).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (513).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (514).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (515).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (516).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (517).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (518).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (519).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (520).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (521).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (522).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (523).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (524).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (525).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (526).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (527).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (528).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (529).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (530).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (531).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (532).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (533).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (534).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (535).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (536).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (537).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (538).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (539).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (540).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (541).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (542).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (543).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (544).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (545).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (546).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (547).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (548).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (549).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (550).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (551).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (552).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (553).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (554).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (555).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (556).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (557).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (558).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (559).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (560).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (561).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (562).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (563).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (564).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (565).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (566).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (567).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (568).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (569).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (570).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (571).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (572).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (573).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (574).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (575).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (576).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (577).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (578).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (579).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (580).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (581).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (582).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (583).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (584).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (585).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (586).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (587).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (588).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (589).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (590).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (591).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (592).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (593).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (594).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (595).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (596).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (597).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (598).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (599).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (600).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (601).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (602).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (603).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (604).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (605).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (606).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (607).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (608).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (609).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (610).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (611).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (612).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (613).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (614).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (615).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (616).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (617).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (618).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (619).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (620).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (621).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (622).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (623).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (624).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (625).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (626).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (627).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (628).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (629).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (630).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (631).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (632).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (633).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (634).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (635).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (636).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (637).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (638).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (639).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (640).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (641).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (642).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (643).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (644).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (645).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (646).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (647).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (648).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (649).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (650).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (651).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (652).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (653).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (654).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (655).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (656).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (657).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (658).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (659).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (660).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (661).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (662).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (663).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (664).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (665).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (666).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (667).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (668).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (669).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (670).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (671).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (672).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (673).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (674).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (675).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (676).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (677).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (678).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (679).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (680).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (681).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (682).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (683).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (684).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (685).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (686).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (687).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (688).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (689).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (690).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (691).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (692).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (693).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (694).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (695).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (696).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (697).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (698).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (699).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (700).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (701).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (702).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (703).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (704).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (705).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (706).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (707).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (708).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (709).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (710).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (711).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (712).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (713).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (714).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (715).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (716).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (717).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (718).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (719).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (720).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (721).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (722).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (723).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (724).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (725).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (726).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (727).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (728).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (729).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (730).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (731).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (732).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (733).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (734).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (735).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (736).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (737).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (738).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (739).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (740).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (741).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (742).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (743).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (744).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (745).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (746).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (747).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (748).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (749).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (750).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (751).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (752).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (753).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (754).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (755).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (756).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (757).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (758).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (759).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (760).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (761).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (762).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (763).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (764).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (765).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (766).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (767).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (768).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (769).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (770).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (771).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (772).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (773).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (774).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (775).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (776).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (777).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (778).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (779).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (780).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (781).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (782).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (783).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (784).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (785).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (786).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (787).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (788).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (789).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (790).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (791).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (792).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (793).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (794).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (795).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (796).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (797).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (798).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (799).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (800).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (801).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (802).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (803).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (804).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (805).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (806).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (807).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (808).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (809).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (810).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (811).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (812).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (813).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (814).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (815).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (816).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (817).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (818).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (819).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (820).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (821).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (822).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (823).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (824).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (825).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (826).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (827).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (828).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (829).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (830).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (831).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (832).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (833).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (834).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (835).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (836).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (837).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (838).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (839).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (840).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (841).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (842).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (843).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (844).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (845).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (846).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (847).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (848).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (849).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (850).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (851).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (852).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (853).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (854).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (855).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (856).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (857).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (858).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (859).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (860).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (861).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (862).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (863).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (864).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (865).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (866).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (867).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (868).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (869).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (870).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (871).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (872).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (873).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (874).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (875).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (876).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (877).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (878).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (879).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (880).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (881).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (882).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (883).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (884).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (885).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (886).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (887).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (888).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (889).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (890).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (891).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (892).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (893).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (894).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (895).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (896).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (897).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (898).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (899).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (900).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (901).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (902).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (903).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (904).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (905).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (906).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (907).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (908).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (909).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (910).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (911).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (912).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (913).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (914).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (915).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (916).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (917).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (918).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (919).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (920).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (921).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (922).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (923).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (924).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (925).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (926).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (927).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (928).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (929).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (930).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (931).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (932).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (933).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (934).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (935).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (936).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (937).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (938).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (939).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (940).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (941).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (942).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (943).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (944).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (945).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (946).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (947).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (948).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (949).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (950).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (951).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (952).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (953).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (954).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (955).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (956).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (957).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (958).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (959).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (960).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (961).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (962).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (963).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (964).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (965).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (966).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (967).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (968).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (969).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (970).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (971).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (972).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (973).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (974).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (975).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (976).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (977).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (978).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (979).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (980).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (981).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (982).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (983).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (984).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (985).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (986).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (987).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (988).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (989).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (990).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (991).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (992).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (993).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (994).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (995).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (996).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (997).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (998).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (999).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1000).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1001).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1002).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1003).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1004).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1005).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1006).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1007).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1008).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1009).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1010).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1011).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1012).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1013).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1014).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1015).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1016).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1017).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1018).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1019).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1020).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1021).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1022).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1023).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1024).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1025).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1026).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1027).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1028).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1029).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1030).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1031).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1032).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1033).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1034).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1035).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1036).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1037).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1038).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1039).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1040).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1041).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1042).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1043).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1044).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1045).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1046).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1047).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1048).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1049).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1050).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1051).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1052).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1053).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1054).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1055).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1056).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1057).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1058).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1059).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1060).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1061).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1062).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1063).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1064).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1065).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1066).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1067).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1068).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1069).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1070).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1071).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1072).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1073).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1074).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1075).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1076).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1077).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1078).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1079).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1080).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1081).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1082).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1083).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1084).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1085).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1086).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1087).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1088).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1089).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1090).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1091).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1092).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1093).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1094).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1095).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1096).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1097).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1098).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1099).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1100).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1101).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1102).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1103).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1104).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1105).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1106).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1107).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1108).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1109).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1110).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1111).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1112).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1113).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1114).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1115).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1116).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1117).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1118).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1119).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1120).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1121).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1122).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1123).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1124).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1125).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1126).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1127).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1128).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1129).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1130).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1131).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1132).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1133).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1134).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1135).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1136).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1137).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1138).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1139).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1140).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1141).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1142).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1143).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1144).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1145).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1146).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1147).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1148).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1149).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1150).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1151).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1152).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1153).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1154).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1155).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1156).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1157).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1158).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1159).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1160).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1161).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1162).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1163).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1164).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1165).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1166).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1167).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1168).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1169).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1170).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1171).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1172).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1173).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1174).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1175).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1176).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1177).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1178).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1179).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1180).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1181).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1182).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1183).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1184).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1185).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1186).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1187).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1188).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1189).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1190).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1191).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1192).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1193).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1194).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1195).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1196).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1197).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1198).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1199).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1200).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1201).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1202).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1203).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1204).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1205).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1206).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1207).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1208).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1209).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1210).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1211).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1212).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1213).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1214).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1215).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1216).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1217).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1218).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1219).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1220).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1221).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1222).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1223).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1224).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1225).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1226).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1227).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1228).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1229).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1230).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1231).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1232).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1233).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1234).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1235).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1236).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1237).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1238).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1239).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1240).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1241).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1242).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1243).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1244).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1245).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1246).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1247).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1248).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1249).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1250).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1251).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1252).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1253).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1254).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1255).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1256).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1257).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1258).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1259).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1260).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1261).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1262).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1263).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1264).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1265).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1266).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1267).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1268).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1269).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1270).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1271).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1272).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1273).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1274).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1275).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1276).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1277).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1278).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1279).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1280).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1281).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1282).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1283).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1284).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1285).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1286).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1287).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1288).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1289).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1290).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1291).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1292).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1293).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1294).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1295).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1296).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1297).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1298).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1299).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1300).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1301).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1302).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1303).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1304).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1305).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1306).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1307).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1308).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1309).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1310).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1311).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1312).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1313).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1314).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1315).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1316).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1317).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1318).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1319).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1320).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1321).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1322).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1323).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1324).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1325).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1326).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1327).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1328).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1329).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1330).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1331).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1332).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1333).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1334).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1335).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1336).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1337).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1338).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1339).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1340).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1341).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1342).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1343).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1344).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1345).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1346).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1347).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1348).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1349).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1350).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1351).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1352).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1353).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1354).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1355).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1356).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1357).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1358).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1359).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1360).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1361).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1362).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1363).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1364).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1365).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1366).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1367).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1368).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1369).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1370).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1371).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1372).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1373).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1374).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1375).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1376).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1377).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1378).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1379).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1380).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1381).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1382).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1383).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1384).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1385).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1386).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1387).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1388).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1389).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1390).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1391).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1392).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1393).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1394).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1395).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1396).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1397).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1398).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1399).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1400).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1401).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1402).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1403).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1404).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1405).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1406).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1407).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1408).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1409).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1410).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1411).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1412).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1413).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1414).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1415).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1416).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1417).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1418).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1419).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1420).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1421).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1422).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1423).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1424).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1425).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1426).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1427).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1428).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1429).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1430).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1431).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1432).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1433).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1434).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1435).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1436).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1437).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1438).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1439).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1440).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1441).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1442).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1443).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1444).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1445).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1446).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1447).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1448).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1449).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1450).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1451).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1452).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1453).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1454).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1455).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1456).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1457).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1458).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1459).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1460).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1461).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1462).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1463).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1464).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1465).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1466).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1467).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1468).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1469).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1470).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1471).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1472).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1473).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1474).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1475).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1476).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1477).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1478).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1479).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1480).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1481).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1482).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1483).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1484).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1485).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1486).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1487).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1488).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1489).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1490).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1491).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1492).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1493).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1494).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1495).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1496).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1497).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1498).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1499).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1500).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1501).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1502).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1503).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1504).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1505).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1506).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1507).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1508).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1509).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1510).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1511).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1512).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1513).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1514).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1515).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1516).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1517).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1518).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1519).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1520).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1521).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1522).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1523).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1524).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1525).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1526).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1527).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1528).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1529).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1530).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1531).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1532).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1533).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1534).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1535).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1536).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1537).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1538).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1539).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1540).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1541).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1542).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1543).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1544).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1545).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1546).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1547).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1548).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1549).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1550).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1551).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1552).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1553).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1554).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1555).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1556).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1557).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1558).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1559).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1560).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1561).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1562).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1563).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1564).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1565).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1566).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1567).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1568).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1569).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1570).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1571).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1572).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1573).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1574).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1575).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1576).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1577).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1578).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1579).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1580).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1581).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1582).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1583).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1584).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1585).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1586).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1587).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1588).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1589).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1590).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1591).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1592).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1593).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1594).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1595).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1596).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1597).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1598).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1599).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1600).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1601).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1602).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1603).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1604).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1605).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1606).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1607).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1608).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1609).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1610).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1611).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1612).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1613).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1614).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1615).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1616).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1617).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1618).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1619).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1620).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1621).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1622).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1623).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1624).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1625).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1626).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1627).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1628).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1629).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1630).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1631).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1632).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1633).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1634).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1635).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1636).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1637).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1638).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1639).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1640).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1641).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1642).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1643).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1644).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1645).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1646).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1647).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1648).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1649).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1650).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1651).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1652).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1653).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1654).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1655).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1656).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1657).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1658).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1659).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1660).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1661).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1662).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1663).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1664).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1665).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1666).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1667).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1668).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1669).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1670).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1671).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1672).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1673).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1674).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1675).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1676).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1677).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1678).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1679).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1680).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1681).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1682).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1683).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1684).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1685).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1686).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1687).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1688).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1689).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1690).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1691).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1692).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1693).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1694).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1695).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1696).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1697).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1698).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1699).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1700).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1701).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1702).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1703).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1704).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1705).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1706).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1707).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1708).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1709).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1710).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1711).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1712).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1713).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1714).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1715).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1716).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1717).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1718).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1719).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1720).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1721).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1722).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1723).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1724).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1725).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1726).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1727).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1728).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1729).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1730).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1731).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1732).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1733).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1734).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1735).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1736).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1737).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1738).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1739).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1740).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1741).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1742).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1743).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1744).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1745).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1746).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1747).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1748).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1749).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1750).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1751).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1752).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1753).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1754).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1755).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1756).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1757).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1758).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1759).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1760).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1761).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1762).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1763).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1764).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1765).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1766).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1767).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1768).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1769).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1770).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1771).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1772).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1773).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1774).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1775).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1776).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1777).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1778).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1779).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1780).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1781).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1782).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1783).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1784).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1785).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1786).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1787).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1788).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1789).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1790).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1791).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1792).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1793).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1794).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1795).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1796).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1797).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1798).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1799).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1800).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1801).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1802).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1803).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1804).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1805).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1806).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1807).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1808).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1809).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1810).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1811).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1812).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1813).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1814).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1815).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1816).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1817).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1818).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1819).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1820).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1821).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1822).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1823).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1824).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1825).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1826).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1827).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1828).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1829).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1830).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1831).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1832).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1833).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1834).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1835).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1836).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1837).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1838).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1839).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1840).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1841).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1842).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1843).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1844).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1845).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1846).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1847).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1848).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1849).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1850).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1851).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1852).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1853).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1854).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1855).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1856).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1857).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1858).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1859).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1860).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1861).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1862).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1863).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1864).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1865).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1866).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1867).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1868).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1869).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1870).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1871).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1872).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1873).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1874).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1875).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1876).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1877).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1878).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1879).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1880).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1881).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1882).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1883).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1884).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1885).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1886).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1887).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1888).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1889).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1890).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1891).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1892).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1893).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1894).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1895).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1896).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1897).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1898).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1899).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1900).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1901).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1902).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1903).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1904).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1905).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1906).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1907).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1908).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1909).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1910).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1911).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1912).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1913).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1914).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1915).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1916).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1917).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1918).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1919).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1920).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1921).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1922).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1923).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1924).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1925).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1926).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1927).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1928).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1929).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1930).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1931).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1932).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1933).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1934).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1935).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1936).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1937).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1938).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1939).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1940).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1941).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1942).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1943).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1944).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1945).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1946).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1947).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1948).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1949).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1950).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1951).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1952).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1953).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1954).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1955).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1956).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1957).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1958).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1959).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1960).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1961).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1962).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1963).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1964).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1965).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1966).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1967).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1968).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1969).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1970).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1971).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1972).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1973).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1974).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1975).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1976).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1977).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1978).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1979).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1980).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1981).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1982).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1983).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1984).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1985).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1986).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1987).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1988).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1989).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1990).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1991).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1992).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1993).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1994).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1995).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1996).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1997).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1998).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (1999).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2000).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2001).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2002).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2003).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2004).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2005).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2006).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2007).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2008).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2009).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2010).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2011).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2012).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2013).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2014).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2015).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2016).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2017).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2018).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2019).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2020).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2021).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2022).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2023).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2024).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2025).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2026).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2027).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2028).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2029).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2030).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2031).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2032).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2033).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2034).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2035).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2036).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2037).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2038).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2039).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2040).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2041).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2042).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2043).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2044).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2045).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2046).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2047).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2048).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2049).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2050).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2051).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2052).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2053).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2054).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2055).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2056).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2057).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2058).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2059).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2060).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2061).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2062).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2063).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2064).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2065).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2066).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2067).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2068).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2069).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2070).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2071).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2072).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2073).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2074).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2075).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2076).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2077).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2078).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2079).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2080).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2081).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2082).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2083).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2084).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2085).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2086).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2087).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2088).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2089).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2090).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2091).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2092).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2093).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2094).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2095).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2096).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2097).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2098).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2099).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2100).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2101).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2102).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2103).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2104).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2105).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2106).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2107).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2108).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2109).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2110).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2111).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2112).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2113).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2114).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2115).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2116).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2117).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2118).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2119).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2120).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2121).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2122).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2123).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2124).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2125).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2126).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2127).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2128).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2129).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2130).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2131).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2132).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2133).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2134).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2135).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2136).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2137).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2138).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2139).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2140).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2141).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2142).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2143).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2144).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2145).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2146).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2147).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2148).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2149).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2150).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2151).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2152).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2153).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2154).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2155).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2156).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2157).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2158).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2159).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2160).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2161).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2162).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2163).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2164).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2165).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2166).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2167).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2168).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2169).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2170).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2171).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2172).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2173).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2174).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2175).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2176).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2177).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2178).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2179).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2180).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2181).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2182).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2183).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2184).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2185).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2186).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2187).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2188).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2189).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2190).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2191).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2192).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2193).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2194).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2195).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2196).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2197).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2198).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2199).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2200).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2201).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2202).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2203).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2204).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2205).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2206).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2207).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2208).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2209).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2210).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2211).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2212).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2213).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2214).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2215).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2216).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2217).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2218).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2219).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2220).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2221).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2222).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2223).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2224).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2225).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2226).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2227).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2228).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2229).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2230).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2231).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2232).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2233).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2234).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2235).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2236).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2237).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2238).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2239).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2240).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2241).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2242).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2243).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2244).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2245).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2246).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2247).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2248).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2249).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2250).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2251).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2252).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2253).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2254).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2255).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2256).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2257).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2258).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2259).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2260).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2261).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2262).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2263).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2264).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2265).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2266).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2267).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2268).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2269).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2270).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2271).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2272).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2273).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2274).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2275).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2276).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2277).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2278).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2279).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2280).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2281).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2282).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2283).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2284).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2285).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2286).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2287).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2288).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2289).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2290).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2291).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2292).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2293).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2294).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2295).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2296).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2297).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2298).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2299).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2300).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2301).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2302).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2303).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2304).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2305).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2306).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2307).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2308).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2309).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2310).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2311).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2312).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2313).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2314).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2315).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2316).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2317).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2318).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2319).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2320).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2321).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2322).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2323).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2324).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2325).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2326).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2327).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2328).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2329).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2330).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2331).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2332).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2333).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2334).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2335).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2336).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2337).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2338).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2339).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2340).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2341).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2342).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2343).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2344).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2345).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2346).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2347).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2348).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2349).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2350).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2351).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2352).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2353).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2354).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2355).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2356).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2357).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2358).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2359).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2360).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2361).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2362).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2363).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2364).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2365).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2366).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2367).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2368).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2369).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2370).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2371).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2372).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2373).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2374).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2375).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2376).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2377).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2378).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2379).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2380).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2381).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2382).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2383).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2384).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2385).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2386).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2387).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2388).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2389).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2390).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2391).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2392).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2393).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2394).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2395).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2396).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2397).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2398).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2399).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2400).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2401).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2402).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2403).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2404).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2405).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2406).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2407).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2408).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2409).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2410).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2411).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2412).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2413).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2414).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2415).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2416).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2417).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2418).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2419).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2420).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2421).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2422).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2423).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2424).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2425).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2426).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2427).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2428).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2429).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2430).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2431).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2432).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2433).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2434).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2435).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2436).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2437).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2438).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2439).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2440).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2441).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2442).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2443).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2444).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2445).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2446).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2447).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2448).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2449).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2450).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2451).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2452).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2453).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2454).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2455).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2456).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2457).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2458).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2459).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2460).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2461).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2462).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2463).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2464).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2465).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2466).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2467).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2468).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2469).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2470).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2471).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2472).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2473).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2474).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2475).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2476).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2477).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2478).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2479).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2480).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2481).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2482).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2483).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2484).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2485).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2486).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2487).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2488).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2489).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2490).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2491).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2492).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2493).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2494).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2495).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2496).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2497).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2498).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2499).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2500).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2501).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2502).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2503).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2504).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2505).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2506).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2507).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2508).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2509).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2510).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2511).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2512).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2513).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2514).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2515).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2516).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2517).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2518).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2519).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2520).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2521).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2522).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2523).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2524).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2525).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2526).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2527).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2528).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2529).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2530).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2531).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2532).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2533).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2534).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2535).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2536).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2537).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2538).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2539).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2540).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2541).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2542).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2543).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2544).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2545).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2546).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2547).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2548).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2549).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2550).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2551).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2552).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2553).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2554).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2555).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2556).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2557).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2558).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2559).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2560).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2561).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2562).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2563).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2564).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2565).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2566).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2567).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2568).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2569).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2570).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2571).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2572).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2573).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2574).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2575).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2576).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2577).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2578).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2579).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2580).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2581).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2582).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2583).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2584).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2585).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2586).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2587).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2588).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2589).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2590).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2591).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2592).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2593).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2594).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2595).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2596).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2597).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2598).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2599).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2600).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2601).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2602).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2603).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2604).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2605).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2606).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2607).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2608).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2609).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2610).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2611).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2612).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2613).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2614).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2615).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2616).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2617).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2618).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2619).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2620).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2621).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2622).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2623).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2624).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2625).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2626).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2627).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2628).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2629).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2630).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2631).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2632).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2633).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2634).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2635).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2636).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2637).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2638).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2639).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2640).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2641).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2642).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2643).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2644).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2645).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2646).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2647).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2648).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2649).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2650).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2651).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2652).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2653).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2654).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2655).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2656).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2657).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2658).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2659).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2660).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2661).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2662).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2663).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2664).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2665).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2666).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2667).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2668).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2669).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2670).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2671).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2672).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2673).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2674).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2675).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2676).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2677).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2678).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2679).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2680).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2681).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2682).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2683).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2684).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2685).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2686).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2687).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2688).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2689).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2690).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2691).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2692).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2693).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2694).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2695).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2696).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2697).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2698).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2699).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2700).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2701).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2702).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2703).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2704).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2705).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2706).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2707).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2708).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2709).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2710).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2711).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2712).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2713).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2714).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2715).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2716).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2717).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2718).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2719).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2720).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2721).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2722).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2723).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2724).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2725).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2726).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2727).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2728).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2729).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2730).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2731).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2732).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2733).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2734).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2735).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2736).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2737).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2738).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2739).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2740).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2741).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2742).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2743).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2744).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2745).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2746).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2747).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2748).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2749).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2750).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2751).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2752).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2753).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2754).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2755).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2756).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2757).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2758).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2759).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2760).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2761).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2762).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2763).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2764).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2765).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2766).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2767).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2768).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2769).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2770).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2771).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2772).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2773).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2774).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2775).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2776).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2777).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2778).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2779).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2780).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2781).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2782).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2783).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2784).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2785).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2786).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2787).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2788).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2789).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2790).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2791).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2792).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2793).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2794).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2795).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2796).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2797).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2798).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2799).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2800).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2801).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2802).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2803).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2804).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2805).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2806).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2807).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2808).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2809).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2810).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2811).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2812).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2813).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2814).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2815).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2816).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2817).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2818).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2819).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2820).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2821).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2822).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2823).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2824).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2825).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2826).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2827).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2828).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2829).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2830).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2831).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2832).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2833).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2834).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2835).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2836).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2837).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2838).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2839).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2840).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2841).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2842).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2843).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2844).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2845).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2846).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2847).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2848).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2849).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2850).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2851).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2852).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2853).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2854).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2855).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2856).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2857).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2858).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2859).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2860).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2861).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2862).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2863).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2864).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2865).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2866).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2867).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2868).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2869).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2870).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2871).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2872).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2873).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2874).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2875).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2876).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2877).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2878).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2879).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2880).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2881).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2882).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2883).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2884).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2885).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2886).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2887).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2888).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2889).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2890).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2891).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2892).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2893).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2894).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2895).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2896).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2897).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2898).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2899).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2900).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2901).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2902).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2903).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2904).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2905).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2906).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2907).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2908).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2909).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2910).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2911).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2912).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2913).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2914).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2915).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2916).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2917).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2918).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2919).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2920).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2921).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2922).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2923).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2924).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2925).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2926).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2927).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2928).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2929).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2930).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2931).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2932).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2933).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2934).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2935).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2936).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2937).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2938).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2939).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2940).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2941).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2942).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2943).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2944).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2945).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2946).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2947).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2948).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2949).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2950).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2951).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2952).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2953).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2954).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2955).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2956).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2957).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2958).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2959).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2960).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2961).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2962).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2963).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2964).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2965).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2966).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2967).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2968).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2969).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2970).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2971).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2972).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2973).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2974).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2975).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2976).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2977).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2978).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2979).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2980).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2981).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2982).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2983).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2984).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2985).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2986).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2987).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2988).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2989).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2990).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2991).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2992).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2993).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2994).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2995).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2996).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2997).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2998).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (2999).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3000).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3001).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3002).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3003).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3004).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3005).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3006).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3007).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3008).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3009).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3010).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3011).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3012).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3013).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3014).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3015).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3016).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3017).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3018).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3019).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3020).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3021).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3022).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3023).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3024).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3025).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3026).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3027).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3028).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3029).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3030).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3031).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3032).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3033).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3034).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3035).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3036).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3037).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3038).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3039).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3040).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3041).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3042).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3043).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3044).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3045).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3046).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3047).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3048).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3049).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3050).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3051).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3052).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3053).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3054).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3055).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3056).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3057).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3058).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3059).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3060).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3061).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3062).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3063).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3064).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3065).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3066).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3067).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3068).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3069).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3070).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3071).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3072).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3073).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3074).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3075).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3076).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3077).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3078).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3079).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3080).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3081).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3082).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3083).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3084).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3085).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3086).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3087).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3088).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3089).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3090).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3091).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3092).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3093).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3094).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3095).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3096).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3097).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3098).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3099).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3100).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3101).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3102).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3103).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3104).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3105).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3106).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3107).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3108).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3109).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3110).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3111).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3112).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3113).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3114).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3115).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3116).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3117).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3118).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3119).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3120).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3121).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3122).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3123).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3124).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3125).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3126).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3127).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3128).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3129).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3130).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3131).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3132).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3133).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3134).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3135).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3136).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3137).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3138).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3139).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3140).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3141).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3142).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3143).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3144).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3145).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3146).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3147).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3148).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3149).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3150).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3151).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3152).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3153).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3154).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3155).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3156).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3157).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3158).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3159).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3160).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3161).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3162).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3163).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3164).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3165).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3166).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3167).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3168).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3169).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3170).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3171).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3172).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3173).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3174).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3175).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3176).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3177).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3178).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3179).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3180).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3181).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3182).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3183).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3184).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3185).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3186).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3187).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3188).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3189).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3190).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3191).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3192).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3193).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3194).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3195).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3196).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3197).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3198).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3199).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3200).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3201).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3202).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3203).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3204).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3205).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3206).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3207).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3208).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3209).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3210).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3211).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3212).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3213).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3214).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3215).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3216).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3217).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3218).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3219).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3220).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3221).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3222).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3223).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3224).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3225).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3226).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3227).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3228).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3229).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3230).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3231).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3232).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3233).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3234).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3235).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3236).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3237).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3238).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3239).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3240).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3241).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3242).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3243).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3244).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3245).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3246).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3247).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3248).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3249).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3250).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3251).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3252).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3253).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3254).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3255).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3256).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3257).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3258).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3259).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3260).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3261).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3262).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3263).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3264).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3265).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3266).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3267).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3268).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3269).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3270).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3271).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3272).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3273).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3274).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3275).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3276).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3277).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3278).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3279).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3280).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3281).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3282).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3283).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3284).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3285).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3286).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3287).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3288).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3289).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3290).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3291).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3292).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3293).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3294).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3295).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3296).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3297).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3298).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3299).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3300).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3301).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3302).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3303).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3304).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3305).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3306).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3307).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3308).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3309).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3310).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3311).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3312).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3313).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3314).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3315).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3316).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3317).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3318).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3319).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3320).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3321).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3322).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3323).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3324).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3325).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3326).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3327).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3328).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3329).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3330).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3331).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3332).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3333).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3334).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3335).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3336).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3337).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3338).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3339).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3340).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3341).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3342).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3343).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3344).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3345).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3346).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3347).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3348).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3349).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3350).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3351).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3352).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3353).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3354).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3355).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3356).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3357).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3358).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3359).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3360).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3361).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3362).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3363).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3364).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3365).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3366).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3367).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3368).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3369).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3370).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3371).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3372).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3373).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3374).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3375).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3376).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3377).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3378).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3379).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3380).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3381).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3382).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3383).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3384).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3385).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3386).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3387).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3388).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3389).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3390).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3391).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3392).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3393).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3394).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3395).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3396).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3397).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3398).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3399).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3400).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3401).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3402).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3403).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3404).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3405).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3406).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3407).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3408).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3409).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3410).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3411).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3412).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3413).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3414).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3415).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3416).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3417).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3418).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3419).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3420).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3421).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3422).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3423).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3424).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3425).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3426).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3427).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3428).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3429).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3430).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3431).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3432).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3433).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3434).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3435).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3436).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3437).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3438).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3439).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3440).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3441).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3442).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3443).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3444).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3445).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3446).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3447).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3448).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3449).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3450).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3451).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3452).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3453).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3454).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3455).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3456).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3457).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3458).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3459).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3460).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3461).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3462).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3463).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3464).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3465).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3466).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3467).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3468).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3469).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3470).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3471).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3472).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3473).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3474).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3475).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3476).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3477).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3478).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3479).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3480).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3481).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3482).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3483).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3484).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3485).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3486).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3487).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3488).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3489).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3490).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3491).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3492).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3493).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3494).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3495).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3496).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3497).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3498).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3499).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3500).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3501).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3502).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3503).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3504).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3505).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3506).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3507).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3508).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3509).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3510).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3511).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3512).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3513).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3514).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3515).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3516).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3517).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3518).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3519).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3520).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3521).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3522).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3523).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3524).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3525).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3526).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3527).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3528).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3529).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3530).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3531).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3532).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3533).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3534).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3535).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3536).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3537).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3538).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3539).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3540).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3541).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3542).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3543).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3544).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3545).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3546).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3547).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3548).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3549).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3550).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3551).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3552).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3553).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3554).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3555).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3556).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3557).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3558).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3559).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3560).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3561).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3562).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3563).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3564).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3565).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3566).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3567).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3568).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3569).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3570).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3571).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3572).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3573).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3574).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3575).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3576).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3577).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3578).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3579).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3580).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3581).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3582).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3583).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3584).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3585).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3586).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3587).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3588).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3589).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3590).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3591).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3592).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3593).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3594).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3595).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3596).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3597).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3598).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3599).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3600).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3601).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3602).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3603).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3604).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3605).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3606).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3607).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3608).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3609).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3610).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3611).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3612).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3613).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3614).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3615).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3616).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3617).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3618).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3619).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3620).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3621).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3622).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3623).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3624).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3625).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3626).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3627).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3628).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3629).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3630).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3631).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3632).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3633).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3634).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3635).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3636).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3637).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3638).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3639).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3640).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3641).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3642).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3643).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3644).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3645).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3646).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3647).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3648).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3649).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3650).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3651).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3652).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3653).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3654).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3655).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3656).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3657).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3658).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3659).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3660).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3661).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3662).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3663).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3664).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3665).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3666).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3667).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3668).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3669).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3670).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3671).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3672).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3673).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3674).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3675).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3676).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3677).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3678).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3679).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3680).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3681).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3682).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3683).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3684).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3685).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3686).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3687).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3688).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3689).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3690).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3691).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3692).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3693).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3694).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3695).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3696).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3697).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3698).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3699).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3700).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3701).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3702).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3703).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3704).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3705).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3706).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3707).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3708).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3709).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3710).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3711).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3712).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3713).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3714).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3715).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3716).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3717).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3718).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3719).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3720).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3721).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3722).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3723).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3724).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3725).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3726).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3727).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3728).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3729).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3730).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3731).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3732).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3733).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3734).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3735).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3736).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3737).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3738).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3739).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3740).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3741).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3742).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3743).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3744).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3745).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3746).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3747).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3748).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3749).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3750).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3751).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3752).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3753).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3754).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3755).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3756).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3757).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3758).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3759).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3760).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3761).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3762).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3763).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3764).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3765).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3766).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3767).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3768).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3769).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3770).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3771).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3772).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3773).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3774).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3775).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3776).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3777).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3778).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3779).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3780).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3781).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3782).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3783).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3784).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3785).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3786).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3787).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3788).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3789).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3790).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3791).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3792).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3793).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3794).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3795).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3796).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3797).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3798).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3799).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3800).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3801).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3802).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3803).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3804).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3805).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3806).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3807).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3808).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3809).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3810).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3811).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3812).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3813).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3814).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3815).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3816).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3817).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3818).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3819).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3820).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3821).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3822).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3823).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3824).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3825).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3826).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3827).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3828).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3829).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3830).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3831).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3832).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3833).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3834).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3835).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3836).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3837).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3838).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3839).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3840).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3841).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3842).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3843).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3844).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3845).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3846).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3847).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3848).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3849).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3850).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3851).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3852).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3853).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3854).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3855).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3856).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3857).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3858).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3859).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3860).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3861).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3862).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3863).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3864).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3865).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3866).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3867).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3868).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3869).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3870).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3871).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3872).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3873).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3874).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3875).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3876).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3877).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3878).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3879).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3880).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3881).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3882).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3883).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3884).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3885).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3886).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3887).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3888).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3889).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3890).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3891).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3892).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3893).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3894).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3895).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3896).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3897).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3898).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3899).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3900).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3901).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3902).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3903).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3904).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3905).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3906).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3907).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3908).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3909).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3910).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3911).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3912).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3913).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3914).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3915).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3916).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3917).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3918).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3919).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3920).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3921).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3922).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3923).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3924).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3925).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3926).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3927).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3928).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3929).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3930).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3931).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3932).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3933).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3934).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3935).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3936).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3937).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3938).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3939).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3940).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3941).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3942).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3943).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3944).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3945).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3946).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3947).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3948).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3949).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3950).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3951).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3952).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3953).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3954).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3955).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3956).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3957).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3958).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3959).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3960).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3961).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3962).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3963).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3964).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3965).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3966).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3967).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3968).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3969).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3970).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3971).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3972).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3973).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3974).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3975).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3976).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3977).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3978).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3979).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3980).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3981).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3982).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3983).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3984).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3985).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3986).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3987).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3988).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3989).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3990).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3991).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3992).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3993).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3994).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3995).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3996).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3997).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3998).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (3999).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4000).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4001).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4002).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4003).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4004).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4005).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4006).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4007).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4008).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4009).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4010).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4011).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4012).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4013).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4014).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4015).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4016).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4017).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4018).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4019).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4020).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4021).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4022).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4023).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4024).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4025).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4026).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4027).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4028).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4029).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4030).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4031).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4032).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4033).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4034).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4035).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4036).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4037).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4038).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4039).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4040).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4041).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4042).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4043).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4044).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4045).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4046).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4047).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4048).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4049).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4050).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4051).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4052).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4053).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4054).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4055).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4056).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4057).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4058).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4059).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4060).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4061).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4062).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4063).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4064).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4065).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4066).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4067).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4068).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4069).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4070).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4071).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4072).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4073).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4074).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4075).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4076).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4077).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4078).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4079).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4080).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4081).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4082).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4083).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4084).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4085).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4086).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4087).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4088).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4089).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4090).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4091).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4092).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4093).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4094).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4095).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4096).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4097).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4098).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4099).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4100).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4101).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4102).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4103).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4104).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4105).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4106).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4107).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4108).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4109).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4110).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4111).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4112).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4113).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4114).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4115).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4116).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4117).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4118).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4119).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4120).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4121).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4122).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4123).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4124).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4125).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4126).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4127).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4128).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4129).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4130).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4131).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4132).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4133).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4134).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4135).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4136).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4137).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4138).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4139).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4140).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4141).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4142).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4143).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4144).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4145).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4146).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4147).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4148).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4149).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4150).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4151).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4152).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4153).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4154).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4155).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4156).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4157).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4158).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4159).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4160).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4161).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4162).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4163).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4164).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4165).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4166).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4167).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4168).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4169).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4170).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4171).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4172).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4173).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4174).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4175).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4176).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4177).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4178).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4179).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4180).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4181).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4182).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4183).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4184).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4185).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4186).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4187).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4188).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4189).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4190).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4191).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4192).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4193).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4194).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4195).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4196).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4197).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4198).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4199).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4200).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4201).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4202).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4203).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4204).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4205).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4206).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4207).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4208).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4209).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4210).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4211).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4212).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4213).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4214).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4215).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4216).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4217).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4218).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4219).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4220).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4221).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4222).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4223).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4224).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4225).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4226).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4227).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4228).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4229).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4230).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4231).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4232).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4233).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4234).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4235).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4236).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4237).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4238).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4239).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4240).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4241).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4242).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4243).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4244).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4245).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4246).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4247).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4248).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4249).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4250).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4251).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4252).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4253).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4254).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4255).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4256).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4257).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4258).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4259).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4260).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4261).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4262).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4263).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4264).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4265).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4266).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4267).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4268).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4269).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4270).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4271).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4272).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4273).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4274).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4275).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4276).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4277).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4278).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4279).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4280).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4281).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4282).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4283).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4284).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4285).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4286).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4287).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4288).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4289).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4290).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4291).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4292).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4293).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4294).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4295).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4296).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4297).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4298).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4299).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4300).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4301).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4302).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4303).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4304).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4305).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4306).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4307).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4308).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4309).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4310).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4311).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4312).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4313).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4314).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4315).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4316).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4317).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4318).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4319).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4320).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4321).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4322).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4323).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4324).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4325).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4326).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4327).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4328).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4329).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4330).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4331).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4332).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4333).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4334).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4335).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4336).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4337).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4338).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4339).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4340).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4341).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4342).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4343).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4344).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4345).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4346).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4347).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4348).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4349).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4350).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4351).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4352).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4353).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4354).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4355).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4356).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4357).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4358).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4359).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4360).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4361).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4362).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4363).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4364).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4365).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4366).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4367).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4368).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4369).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4370).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4371).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4372).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4373).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4374).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4375).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4376).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4377).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4378).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4379).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4380).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4381).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4382).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4383).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4384).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4385).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4386).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4387).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4388).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4389).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4390).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4391).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4392).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4393).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4394).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4395).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4396).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4397).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4398).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4399).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4400).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4401).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4402).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4403).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4404).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4405).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4406).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4407).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4408).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4409).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4410).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4411).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4412).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4413).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4414).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4415).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4416).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4417).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4418).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4419).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4420).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4421).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4422).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4423).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4424).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4425).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4426).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4427).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4428).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4429).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4430).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4431).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4432).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4433).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4434).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4435).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4436).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4437).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4438).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4439).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4440).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4441).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4442).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4443).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4444).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4445).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4446).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4447).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4448).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4449).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4450).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4451).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4452).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4453).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4454).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4455).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4456).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4457).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4458).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4459).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4460).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4461).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4462).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4463).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4464).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4465).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4466).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4467).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4468).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4469).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4470).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4471).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4472).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4473).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4474).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4475).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4476).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4477).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4478).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4479).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4480).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4481).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4482).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4483).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4484).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4485).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4486).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4487).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4488).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4489).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4490).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4491).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4492).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4493).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4494).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4495).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4496).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4497).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4498).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4499).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4500).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4501).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4502).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4503).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4504).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4505).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4506).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4507).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4508).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4509).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4510).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4511).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4512).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4513).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4514).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4515).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4516).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4517).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4518).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4519).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4520).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4521).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4522).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4523).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4524).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4525).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4526).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4527).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4528).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4529).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4530).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4531).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4532).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4533).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4534).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4535).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4536).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4537).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4538).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4539).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4540).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4541).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4542).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4543).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4544).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4545).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4546).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4547).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4548).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4549).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4550).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4551).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4552).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4553).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4554).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4555).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4556).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4557).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4558).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4559).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4560).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4561).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4562).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4563).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4564).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4565).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4566).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4567).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4568).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4569).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4570).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4571).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4572).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4573).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4574).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4575).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4576).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4577).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4578).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4579).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4580).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4581).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4582).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4583).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4584).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4585).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4586).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4587).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4588).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4589).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4590).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4591).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4592).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4593).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4594).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4595).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4596).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4597).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4598).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4599).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4600).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4601).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4602).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4603).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4604).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4605).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4606).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4607).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4608).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4609).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4610).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4611).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4612).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4613).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4614).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4615).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4616).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4617).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4618).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4619).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4620).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4621).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4622).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4623).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4624).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4625).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4626).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4627).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4628).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4629).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4630).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4631).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4632).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4633).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4634).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4635).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4636).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4637).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4638).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4639).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4640).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4641).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4642).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4643).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4644).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4645).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4646).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4647).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4648).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4649).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4650).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4651).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4652).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4653).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4654).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4655).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4656).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4657).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4658).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4659).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4660).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4661).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4662).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4663).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4664).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4665).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4666).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4667).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4668).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4669).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4670).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4671).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4672).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4673).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4674).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4675).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4676).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4677).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4678).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4679).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4680).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4681).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4682).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4683).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4684).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4685).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4686).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4687).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4688).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4689).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4690).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4691).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4692).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4693).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4694).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4695).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4696).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4697).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4698).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4699).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4700).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4701).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4702).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4703).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4704).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4705).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4706).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4707).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4708).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4709).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4710).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4711).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4712).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4713).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4714).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4715).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4716).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4717).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4718).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4719).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4720).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4721).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4722).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4723).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4724).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4725).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4726).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4727).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4728).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4729).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4730).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4731).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4732).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4733).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4734).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4735).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4736).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4737).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4738).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4739).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4740).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4741).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4742).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4743).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4744).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4745).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4746).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4747).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4748).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4749).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4750).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4751).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4752).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4753).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4754).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4755).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4756).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4757).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4758).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4759).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4760).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4761).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4762).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4763).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4764).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4765).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4766).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4767).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4768).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4769).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4770).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4771).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4772).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4773).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4774).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4775).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4776).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4777).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4778).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4779).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4780).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4781).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4782).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4783).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4784).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4785).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4786).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4787).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4788).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4789).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4790).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4791).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4792).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4793).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4794).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4795).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4796).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4797).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4798).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4799).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4800).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4801).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4802).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4803).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4804).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4805).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4806).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4807).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4808).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4809).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4810).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4811).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4812).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4813).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4814).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4815).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4816).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4817).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4818).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4819).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4820).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4821).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4822).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4823).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4824).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4825).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4826).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4827).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4828).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4829).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4830).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4831).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4832).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4833).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4834).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4835).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4836).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4837).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4838).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4839).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4840).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4841).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4842).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4843).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4844).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4845).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4846).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4847).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4848).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4849).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4850).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4851).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4852).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4853).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4854).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4855).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4856).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4857).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4858).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4859).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4860).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4861).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4862).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4863).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4864).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4865).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4866).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4867).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4868).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4869).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4870).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4871).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4872).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4873).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4874).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4875).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4876).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4877).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4878).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4879).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4880).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4881).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4882).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4883).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4884).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4885).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4886).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4887).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4888).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4889).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4890).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4891).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4892).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4893).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4894).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4895).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4896).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4897).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4898).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4899).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4900).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4901).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4902).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4903).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4904).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4905).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4906).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4907).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4908).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4909).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4910).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4911).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4912).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4913).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4914).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4915).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4916).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4917).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4918).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4919).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4920).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4921).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4922).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4923).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4924).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4925).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4926).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4927).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4928).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4929).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4930).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4931).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4932).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4933).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4934).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4935).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4936).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4937).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4938).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4939).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4940).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4941).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4942).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4943).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4944).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4945).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4946).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4947).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4948).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4949).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4950).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4951).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4952).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4953).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4954).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4955).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4956).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4957).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4958).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4959).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4960).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4961).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4962).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4963).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4964).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4965).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4966).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4967).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4968).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4969).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4970).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4971).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4972).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4973).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4974).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4975).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4976).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4977).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4978).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4979).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4980).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4981).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4982).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4983).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4984).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4985).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4986).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4987).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4988).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4989).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4990).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4991).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4992).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4993).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4994).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4995).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4996).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4997).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4998).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (4999).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5000).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5001).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5002).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5003).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5004).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5005).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5006).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5007).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5008).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5009).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5010).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5011).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5012).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5013).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5014).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5015).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5016).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5017).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5018).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5019).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5020).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5021).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5022).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5023).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5024).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5025).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5026).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5027).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5028).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5029).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5030).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5031).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5032).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5033).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5034).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5035).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5036).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5037).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5038).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5039).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5040).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5041).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5042).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5043).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5044).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5045).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5046).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5047).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5048).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5049).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5050).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5051).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5052).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5053).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5054).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5055).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5056).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5057).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5058).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5059).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5060).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5061).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5062).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5063).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5064).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5065).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5066).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5067).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5068).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5069).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5070).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5071).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5072).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5073).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5074).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5075).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5076).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5077).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5078).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5079).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5080).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5081).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5082).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5083).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5084).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5085).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5086).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5087).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5088).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5089).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5090).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5091).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5092).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5093).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5094).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5095).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5096).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5097).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5098).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5099).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5100).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5101).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5102).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5103).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5104).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5105).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5106).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5107).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5108).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5109).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5110).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5111).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5112).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5113).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5114).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5115).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5116).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5117).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5118).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5119).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5120).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5121).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5122).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5123).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5124).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5125).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5126).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5127).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5128).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5129).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5130).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5131).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5132).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5133).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5134).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5135).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5136).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5137).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5138).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5139).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5140).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5141).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5142).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5143).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5144).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5145).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5146).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5147).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5148).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5149).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5150).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5151).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5152).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5153).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5154).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5155).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5156).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5157).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5158).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5159).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5160).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5161).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5162).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5163).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5164).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5165).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5166).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5167).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5168).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5169).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5170).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5171).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5172).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5173).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5174).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5175).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5176).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5177).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5178).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5179).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5180).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5181).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5182).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5183).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5184).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5185).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5186).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5187).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5188).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5189).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5190).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5191).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5192).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5193).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5194).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5195).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5196).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5197).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5198).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5199).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5200).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5201).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5202).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5203).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5204).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5205).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5206).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5207).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5208).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5209).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5210).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5211).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5212).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5213).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5214).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5215).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5216).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5217).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5218).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5219).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5220).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5221).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5222).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5223).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5224).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5225).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5226).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5227).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5228).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5229).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5230).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5231).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5232).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5233).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5234).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5235).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5236).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5237).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5238).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5239).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5240).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5241).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5242).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5243).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5244).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5245).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5246).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5247).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5248).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5249).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5250).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5251).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5252).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5253).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5254).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5255).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5256).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5257).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5258).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5259).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5260).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5261).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5262).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5263).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5264).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5265).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5266).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5267).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5268).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5269).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5270).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5271).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5272).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5273).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5274).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5275).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5276).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5277).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5278).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5279).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5280).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5281).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5282).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5283).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5284).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5285).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5286).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5287).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5288).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5289).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5290).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5291).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5292).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5293).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5294).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5295).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5296).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5297).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5298).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5299).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5300).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5301).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5302).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5303).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5304).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5305).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5306).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5307).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5308).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5309).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5310).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5311).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5312).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5313).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5314).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5315).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5316).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5317).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5318).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5319).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5320).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5321).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5322).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5323).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5324).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5325).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5326).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5327).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5328).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5329).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5330).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5331).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5332).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5333).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5334).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5335).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5336).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5337).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5338).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5339).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5340).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5341).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5342).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5343).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5344).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5345).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5346).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5347).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5348).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5349).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5350).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5351).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5352).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5353).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5354).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5355).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5356).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5357).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5358).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5359).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5360).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5361).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5362).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5363).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5364).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5365).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5366).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5367).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5368).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5369).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5370).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5371).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5372).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5373).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5374).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5375).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5376).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5377).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5378).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5379).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5380).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5381).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5382).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5383).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5384).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5385).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5386).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5387).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5388).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5389).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5390).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5391).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5392).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5393).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5394).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5395).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5396).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5397).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5398).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5399).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5400).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5401).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5402).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5403).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5404).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5405).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5406).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5407).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5408).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5409).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5410).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5411).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5412).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5413).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5414).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5415).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5416).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5417).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5418).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5419).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5420).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5421).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5422).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5423).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5424).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5425).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5426).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5427).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5428).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5429).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5430).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5431).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5432).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5433).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5434).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5435).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5436).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5437).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5438).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5439).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5440).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5441).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5442).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5443).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5444).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5445).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5446).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5447).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5448).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5449).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5450).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5451).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5452).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5453).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5454).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5455).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5456).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5457).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5458).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5459).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5460).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5461).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5462).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5463).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5464).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5465).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5466).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5467).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5468).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5469).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5470).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5471).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5472).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5473).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5474).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5475).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5476).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5477).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5478).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5479).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5480).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5481).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5482).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5483).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5484).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5485).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5486).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5487).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5488).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5489).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5490).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5491).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5492).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5493).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5494).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5495).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5496).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5497).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5498).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5499).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5500).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5501).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5502).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5503).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5504).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5505).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5506).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5507).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5508).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5509).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5510).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5511).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5512).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5513).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5514).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5515).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5516).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5517).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5518).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5519).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5520).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5521).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5522).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5523).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5524).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5525).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5526).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5527).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5528).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5529).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5530).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5531).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5532).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5533).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5534).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5535).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5536).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5537).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5538).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5539).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5540).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5541).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5542).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5543).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5544).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5545).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5546).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5547).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5548).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5549).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5550).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5551).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5552).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5553).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5554).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5555).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5556).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5557).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5558).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5559).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5560).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5561).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5562).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5563).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5564).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5565).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5566).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5567).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5568).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5569).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5570).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5571).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5572).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5573).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5574).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5575).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5576).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5577).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5578).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5579).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5580).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5581).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5582).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5583).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5584).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5585).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5586).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5587).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5588).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5589).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5590).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5591).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5592).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5593).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5594).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5595).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5596).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5597).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5598).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5599).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5600).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5601).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5602).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5603).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5604).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5605).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5606).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5607).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5608).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5609).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5610).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5611).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5612).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5613).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5614).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5615).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5616).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5617).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5618).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5619).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5620).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5621).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5622).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5623).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5624).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5625).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5626).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5627).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5628).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5629).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5630).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5631).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5632).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5633).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5634).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5635).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5636).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5637).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5638).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5639).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5640).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5641).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5642).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5643).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5644).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5645).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5646).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5647).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5648).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5649).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5650).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5651).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5652).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5653).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5654).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5655).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5656).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5657).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5658).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5659).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5660).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5661).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5662).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5663).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5664).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5665).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5666).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5667).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5668).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5669).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5670).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5671).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5672).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5673).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5674).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5675).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5676).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5677).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5678).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5679).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5680).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5681).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5682).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5683).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5684).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5685).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5686).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5687).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5688).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5689).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5690).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5691).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5692).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5693).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5694).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5695).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5696).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5697).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5698).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5699).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5700).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5701).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5702).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5703).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5704).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5705).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5706).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5707).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5708).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5709).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5710).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5711).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5712).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5713).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5714).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5715).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5716).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5717).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5718).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5719).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5720).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5721).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5722).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5723).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5724).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5725).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5726).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5727).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5728).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5729).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5730).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5731).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5732).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5733).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5734).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5735).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5736).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5737).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5738).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5739).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5740).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5741).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5742).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5743).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5744).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5745).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5746).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5747).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5748).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5749).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5750).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5751).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5752).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5753).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5754).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5755).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5756).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5757).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5758).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5759).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5760).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5761).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5762).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5763).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5764).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5765).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5766).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5767).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5768).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5769).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5770).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5771).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5772).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5773).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5774).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5775).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5776).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5777).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5778).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5779).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5780).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5781).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5782).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5783).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5784).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5785).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5786).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5787).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5788).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5789).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5790).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5791).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5792).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5793).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5794).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5795).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5796).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5797).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5798).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5799).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5800).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5801).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5802).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5803).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5804).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5805).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5806).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5807).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5808).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5809).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5810).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5811).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5812).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5813).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5814).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5815).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5816).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5817).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5818).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5819).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5820).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5821).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5822).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5823).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5824).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5825).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5826).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5827).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5828).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5829).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5830).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5831).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5832).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5833).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5834).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5835).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5836).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5837).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5838).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5839).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5840).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5841).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5842).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5843).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5844).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5845).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5846).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5847).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5848).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5849).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5850).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5851).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5852).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5853).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5854).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5855).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5856).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5857).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5858).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5859).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5860).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5861).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5862).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5863).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5864).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5865).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5866).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5867).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5868).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5869).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5870).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5871).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5872).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5873).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5874).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5875).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5876).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5877).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5878).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5879).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5880).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5881).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5882).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5883).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5884).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5885).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5886).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5887).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5888).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5889).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5890).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5891).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5892).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5893).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5894).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5895).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5896).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5897).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5898).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5899).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5900).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5901).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5902).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5903).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5904).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5905).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5906).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5907).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5908).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5909).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5910).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5911).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5912).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5913).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5914).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5915).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5916).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5917).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5918).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5919).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5920).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5921).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5922).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5923).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5924).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5925).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5926).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5927).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5928).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5929).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5930).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5931).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5932).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5933).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5934).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5935).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5936).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5937).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5938).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5939).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5940).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5941).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5942).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5943).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5944).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5945).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5946).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5947).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5948).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5949).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5950).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5951).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5952).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5953).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5954).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5955).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5956).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5957).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5958).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5959).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5960).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5961).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5962).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5963).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5964).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5965).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5966).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5967).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5968).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5969).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5970).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5971).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5972).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5973).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5974).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5975).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5976).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5977).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5978).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5979).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5980).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5981).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5982).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5983).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5984).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5985).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5986).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5987).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5988).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5989).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5990).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5991).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5992).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5993).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5994).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5995).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5996).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5997).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5998).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (5999).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6000).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6001).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6002).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6003).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6004).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6005).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6006).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6007).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6008).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6009).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6010).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6011).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6012).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6013).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6014).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6015).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6016).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6017).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6018).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6019).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6020).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6021).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6022).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6023).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6024).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6025).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6026).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6027).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6028).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6029).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6030).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6031).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6032).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6033).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6034).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6035).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6036).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6037).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6038).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6039).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6040).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6041).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6042).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6043).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6044).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6045).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6046).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6047).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6048).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6049).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6050).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6051).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6052).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6053).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6054).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6055).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6056).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6057).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6058).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6059).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6060).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6061).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6062).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6063).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6064).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6065).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6066).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6067).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6068).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6069).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6070).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6071).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6072).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6073).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6074).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6075).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6076).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6077).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6078).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6079).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6080).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6081).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6082).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6083).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6084).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6085).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6086).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6087).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6088).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6089).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6090).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6091).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6092).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6093).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6094).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6095).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6096).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6097).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6098).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6099).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6100).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6101).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6102).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6103).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6104).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6105).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6106).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6107).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6108).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6109).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6110).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6111).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6112).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6113).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6114).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6115).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6116).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6117).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6118).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6119).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6120).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6121).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6122).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6123).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6124).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6125).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6126).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6127).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6128).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6129).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6130).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6131).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6132).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6133).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6134).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6135).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6136).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6137).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6138).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6139).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6140).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6141).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6142).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6143).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6144).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6145).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6146).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6147).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6148).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6149).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6150).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6151).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6152).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6153).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6154).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6155).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6156).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6157).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6158).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6159).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6160).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6161).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6162).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6163).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6164).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6165).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6166).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6167).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6168).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6169).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6170).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6171).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6172).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6173).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6174).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6175).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6176).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6177).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6178).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6179).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6180).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6181).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6182).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6183).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6184).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6185).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6186).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6187).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6188).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6189).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6190).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6191).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6192).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6193).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6194).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6195).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6196).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6197).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6198).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6199).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6200).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6201).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6202).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6203).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6204).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6205).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6206).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6207).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6208).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6209).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6210).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6211).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6212).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6213).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6214).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6215).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6216).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6217).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6218).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6219).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6220).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6221).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6222).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6223).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6224).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6225).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6226).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6227).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6228).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6229).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6230).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6231).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6232).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6233).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6234).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6235).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6236).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6237).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6238).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6239).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6240).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6241).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6242).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6243).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6244).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6245).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6246).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6247).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6248).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6249).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6250).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6251).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6252).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6253).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6254).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6255).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6256).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6257).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6258).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6259).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6260).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6261).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6262).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6263).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6264).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6265).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6266).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6267).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6268).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6269).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6270).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6271).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6272).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6273).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6274).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6275).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6276).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6277).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6278).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6279).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6280).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6281).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6282).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6283).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6284).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6285).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6286).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6287).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6288).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6289).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6290).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6291).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6292).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6293).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6294).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6295).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6296).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6297).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6298).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6299).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6300).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6301).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6302).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6303).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6304).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6305).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6306).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6307).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6308).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6309).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6310).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6311).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6312).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6313).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6314).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6315).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6316).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6317).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6318).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6319).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6320).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6321).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6322).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6323).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6324).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6325).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6326).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6327).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6328).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6329).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6330).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6331).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6332).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6333).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6334).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6335).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6336).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6337).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6338).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6339).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6340).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6341).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6342).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6343).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6344).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6345).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6346).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6347).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6348).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6349).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6350).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6351).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6352).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6353).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6354).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6355).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6356).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6357).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6358).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6359).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6360).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6361).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6362).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6363).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6364).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6365).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6366).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6367).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6368).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6369).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6370).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6371).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6372).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6373).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6374).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6375).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6376).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6377).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6378).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6379).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6380).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6381).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6382).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6383).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6384).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6385).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6386).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6387).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6388).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6389).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6390).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6391).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6392).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6393).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6394).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6395).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6396).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6397).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6398).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6399).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6400).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6401).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6402).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6403).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6404).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6405).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6406).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6407).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6408).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6409).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6410).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6411).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6412).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6413).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6414).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6415).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6416).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6417).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6418).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6419).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6420).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6421).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6422).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6423).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6424).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6425).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6426).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6427).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6428).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6429).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6430).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6431).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6432).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6433).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6434).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6435).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6436).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6437).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6438).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6439).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6440).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6441).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6442).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6443).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6444).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6445).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6446).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6447).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6448).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6449).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6450).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6451).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6452).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6453).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6454).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6455).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6456).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6457).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6458).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6459).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6460).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6461).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6462).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6463).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6464).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6465).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6466).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6467).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6468).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6469).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6470).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6471).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6472).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6473).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6474).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6475).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6476).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6477).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6478).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6479).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6480).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6481).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6482).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6483).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6484).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6485).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6486).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6487).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6488).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6489).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6490).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6491).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6492).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6493).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6494).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6495).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6496).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6497).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6498).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6499).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6500).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6501).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6502).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6503).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6504).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6505).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6506).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6507).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6508).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6509).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6510).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6511).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6512).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6513).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6514).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6515).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6516).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6517).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6518).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6519).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6520).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6521).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6522).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6523).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6524).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6525).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6526).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6527).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6528).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6529).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6530).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6531).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6532).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6533).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6534).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6535).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6536).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6537).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6538).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6539).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6540).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6541).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6542).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6543).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6544).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6545).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6546).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6547).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6548).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6549).png').convert('1')
disp.image(image)

disp.display()
image = Image.open('bad (6550).png').convert('1')
disp.image(image)

disp.display()

